gps = function(positions, times, v, tol=1e-10)  {
  ## convert the dataframe to a matrix
  ## we use the notation of reference [2]
  ## The "z" column need not be present.
  
  ## either 2 or 3 dimensions
  dim = ncol(positions)

  ## lorentz coefficients are 1 for spatial, -1 for time
  lorentz.coef = c(rep(1, dim), -1)

  ## lorentz inner product
  lorentz = function(x1, x2=x1) {
     return (sum (lorentz.coef * x1 * x2))
  }

  ## the pseudo range
  rho = - v * times

  ## add the pseudorange column to get B
  B = cbind(positions, rho)

  ## the vector of ones
  e = rep(1, nrow(B))

  ## the vector of squared lorentz norms 
  a = 0.5 * apply(B, 1, lorentz)

  ## use the pseudo-inverse of B to get B+ e, B+ a
  ## via QR decomposition of B
  
  qrB = qr(B, tol = tol)
  Binv.e = solve(qrB, e, tol = tol)
  Binv.a = solve(qrB, a, tol = tol)

  ## the coefficients for the quadratic equation in lambda
  
  cA = lorentz(Binv.e)
  cB = 2 * (lorentz(Binv.e, Binv.a) - 1)
  cC = lorentz(Binv.a)

  desc = cB^2-4*cA*cC

  ## if the descriminant is negative, we cheat and
  ## set it to zero, so that we still get a solution,
  ## albeit a probably not very good one!
  
  if (desc < 0)
    desc = 0

  ## solve the quadratic
  lambda = (-cB + c(-1, 1) * sqrt(desc)) / (2*cA)

  ## get the solution for each possible lambda
  
  u1 = solve(qrB, (a + lambda[1] * e), tol = tol)
  u2 = solve(qrB, (a + lambda[2] * e), tol = tol)

  ## return the solution with the lower sum of squares
  ## discrepancy
  
  s1 = sum( (B %*% u1 - (a + lambda[1] * e))^2)
  s2 = sum( (B %*% u2 - (a + lambda[2] * e))^2)

  u = if (s1 < s2) u1 else u2

  err.rms = sqrt(min(s1, s2) / nrow(B))

  ## rms space error 
  err.space =  sqrt(mean(apply(B, 1,
                   function(x) {
                     (sqrt(sum((u[1:dim]-x[1:dim])^2)) + x[1+dim] + u[1+dim])^2
                   })))
  ## rms time error
  err.time = err.space / v

  u = as.list(u)
  names(u) = c("east", "north", if(dim == 3) "z", "time")

  ## convert distance offset to time offset
  u$time = u$time / v

  ## return as a list to allow simpler indexing of components, and append errors
  return(c(u, err.rms=err.rms, err.space=err.space, err.time=err.time))
}
