localize = function(mics = getAFilename("Choose a Microphone Coordinates File", rbind(c("Comma-Separated Values (*.csv)", "*.csv"), Filters["All"])), sounds = getAFilename("Choose a Sounds File", rbind(c("Comma-Separated Values (*.csv)", "*.csv"), Filters["All"])), temps=NULL, tol=1e-10) {
  ## maybe read mic positions from a file
  if (is.character(mics))
    mics = read.csv(mics, as.is=TRUE)

  ## maybe read sound times from a file
  ## and if so, remember the name
  sounds.from.file = is.character(sounds)
  if (sounds.from.file) {
    sounds.filename = sounds
    sounds = read.csv(sounds, as.is=TRUE)
  }

  ## the required names of TOADS / timestamps columns, given the number of mics
  mic.cols = paste("t", 1:nrow(mics), sep="")
  
  ## ensure the correct TOADS / timestamps columns are present in sounds
  if (! all ( mic.cols %in% names(sounds)))
    stop("the sounds object must have a column for TOADS or timestamp at each mic,\nand these must be named t1, t2, ... ", tail(mic.cols, 1))

  ## ensure the temps are specified for each sound, if no temps parameter is given
  if (is.null(temps) && is.null(sounds$temp))
    stop("you must either specify a number, data.frame, or filename for temps,\nor the sounds object must have a column named 'temp'")
  
  ## maybe read temps from a file
  if (is.character(temps))
    temps = read.csv(temps, as.is=TRUE)

  ## get the temperature for each sound
  if (!is.null(sounds$temp)) {
    ## temperatures are specified for each sound
    temps = sounds$temp
  } else if (is.data.frame(temps)) {
    ## temperatures are given as a time series, so apply an interpolation to the mean TOADS / timestamp
    ## for each sound
    temps = spline(temps$time, temps$temp, xout=apply(as.matrix(sounds[, mic.cols]), 1, mean, na.rm=TRUE), method="natural")$y
  } else {
    ## re-use the value in temps for each sound
    temps = rep(temps, length=nrow(sounds))
  }
    
  ## the number of sounds to localize
  n = nrow(sounds)

  ## we're doing 3d if "z" is specified for microphone locations
  is.3d = ! is.null(mics$z)

  ## names of coordinate columns for microphones
  mic.coords = cbind(mics$east, mics$north, mics$z)
  
  ## add columns to the input dataframe for the estimates
  sounds$east = sounds$north = sounds$v = numeric(n)
  if (is.3d)
    sounds$z = numeric(n)
  sounds$err.millisecs = sounds$err.metres = sounds$err.rms = sounds$time = numeric(n)
  
  ## for improved numerical stability, translate coordinates
  ## so the origin is at their mean; we'll convert back
  ## after doing the estimation
  
  origin = apply(mic.coords, 2, mean)

  mic.coords = sweep(mic.coords, 2, origin)

  ## keep track of whether we've warned the user about reversed timestamps
  have.warned = FALSE

  ## loop over each sound
  for (i in 1:nrow(sounds)) {

    ## keep only mics for which the sound was detected
    keep <- ! is.na(sounds[i, mic.cols])
    used.mics = mic.coords[keep,]
    t = as.numeric(sounds[i, mic.cols[keep]])

    ## if all signs are non-positive, assume we need to negate
    ## them (we want increasing time to represent "later", as usual)

    if (all(t <= 0)) {
      t = -t
      if (! have.warned) {
        
        warning("localize: times in the sounds matrix should be oriented so that larger
 is further in the future; I'm negating the values you supplied, as they are all non-positive,
which suggests their orientation is reversed")
        
        have.warned = TRUE
      }
    }
    
    ## calculate the speed of sound, given the interpolated
    ## temperature at the time of the first microphone's detection of
    ## this sound
    
    v = 331.3 * sqrt(1 + temps[i] / 273.15)

    ## get "mean" time for translating below (we kludge this and always use 64
    ## as the denominator, to match SoundFinder.xls)
    mean.t = sum(t) / 64
    t = t - mean.t
    
    ## invoke the GPS solver

    soln = gps(used.mics, t, v, tol)

    ## fill in the output row

    sounds$east[i]          = soln$east + origin[1]
    sounds$north[i]         = soln$north + origin[2]
    if (is.3d)
      sounds$z[i]           = soln$z + origin[3]
    sounds$time[i]          = soln$time + mean.t
    sounds$v[i]             = v
    sounds$err.rms[i]       = soln$err.rms
    sounds$err.metres[i]    = soln$err.space
    sounds$err.millisecs[i] = soln$err.time * 1000
  }
  
  if (sounds.from.file) {
    ## write solution-augmented input back to the file it came from
    write.csv(sounds, file=sounds.filename, row.names=FALSE)
  }

  return (sounds)
}
