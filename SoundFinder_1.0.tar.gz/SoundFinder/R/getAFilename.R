getAFilename = function(caption, filters, multi=FALSE) {
  switch (.Platform$OS.type,
          unix = {
            if (.Platform$GUI == "AQUA") {
              ## Mac: can't seem to set caption on file dialogue
              cat(caption, "\n")
              choose.files(caption=caption, filters = filters, multi=multi, index=1)
            } else {
              ## Linux:
              cat(caption, "\n")
              return (file.choose())
            }
          },
          windows = {
            return (choose.files(caption=caption, filters = filters, multi=multi, index=1))
          },
          
          )
}
